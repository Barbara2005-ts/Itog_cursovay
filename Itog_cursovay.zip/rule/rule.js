document.addEventListener('DOMContentLoaded', function () {
    // Добавьте в DOMContentLoaded:
    document.getElementById('login-btn').addEventListener('click', loginUser);
    // Слайдер
    const slider = {
        currentSlide: 0,
        slides: document.querySelectorAll('.slide'),

        init: function() {
            this.updateSlide();
        },

        updateSlide: function() {
            this.slides.forEach((slide, index) => {
                slide.classList.toggle('hidden', index !== this.currentSlide);
                if (index === this.currentSlide) {
                    slide.style.animation = 'fadeIn 0.5s ease';
                }
            });
            this.updateButtons();
        },

        updateButtons: function() {
            const currentSlide = this.slides[this.currentSlide];
            const prevBtns = currentSlide.querySelectorAll('.prev-button');
            const nextBtns = currentSlide.querySelectorAll('.next-button');

            prevBtns.forEach(btn => {
                btn.style.display = this.currentSlide === 0 ? 'none' : 'block';
            });

            nextBtns.forEach(btn => {
                btn.style.display = this.currentSlide === this.slides.length - 1 ? 'none' : 'block';
            });
        },

        nextSlide: function() {
            if (this.currentSlide < this.slides.length - 1) {
                this.currentSlide++;
                this.updateSlide();
            }
        },

        prevSlide: function() {
            if (this.currentSlide > 0) {
                this.currentSlide--;
                this.updateSlide();
            }
        }
    };

    // Модальные окна
    const modal = {
        init: function() {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.style.display = 'none';
            });

            window.addEventListener('click', function(event) {
                if (event.target.classList.contains('modal')) {
                    modal.close(event.target.id);
                }
            });
        },

        open: function(id) {
            const modalElement = document.getElementById(id);
            if (modalElement) {
                modalElement.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }
        },

        close: function(id) {
            const modalElement = document.getElementById(id);
            if (modalElement) {
                modalElement.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }
    };

    // Supabase (замени на свои ключи в .env или через сервер)
    const supabaseClient = supabase.createClient(
        'https://rjhqvhwlwdhpbrtytxxp.supabase.co',
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJqaHF2aHdsd2RocGJydHl0eHhwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUyNjkwNjMsImV4cCI6MjA2MDg0NTA2M30.UuSxSWlp8VSyUyEsGFNkPQm3n2mqRw_hw7kDdz_DqSg'
    );

        // Включите логирование всех запросов Supabase
    supabaseClient.auth.onAuthStateChange((event, session) => {
        console.log('Auth Event:', event, 'Session:', session);
    });
    async function registerUser() {
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        const username = document.getElementById('username').value;
    
        if (!username) {
            alert('Пожалуйста, введите имя пользователя!');
            return;
        }
    
        try {
            // 1. Регистрация в Supabase Auth
            const { data: signUpData, error: signUpError } = await supabaseClient.auth.signUp({
                email,
                password,
                options: {
                    data: {
                        username: username  // Добавляем username в метаданные пользователя
                    }
                }
            });
    
            if (signUpError) {
                console.error('Auth Error:', signUpError);
                throw signUpError;
            }
    
            // 2. Обновляем username в public.users (если триггер уже создал запись)
            const { error: updateError } = await supabaseClient
                .from('users')
                .update({ username })
                .eq('id', signUpData.user.id);
    
            if (updateError && !updateError.message.includes('No rows found')) {
                console.error('Update Error:', updateError);
                throw updateError;
            }
    
            // 3. Успех
            localStorage.setItem('username', username);
            alert('Проверьте вашу почту для подтверждения!');
            closeModal('modalRegister');
            nextSlide();
            window.location.href = '../account/account.html';
    
        } catch (error) {
            console.error('Full Error:', error);
            alert('Ошибка регистрации: ' + error.message);
        }
    }

    async function loginUser() {
        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('login-password').value.trim();
        
        if (!email || !password) {
            alert('Пожалуйста, заполните все поля!');
            return;
        }
    
        try {
            const { data, error } = await supabaseClient.auth.signInWithPassword({
                email,
                password
            });
    
            if (error) {
                console.error('Login Error:', error);
                
                // Специальная обработка ошибки неподтвержденного email
                if (error.message.includes('email not confirmed')) {
                    if (confirm('Email не подтвержден. Отправить письмо с подтверждением?')) {
                        await supabaseClient.auth.resend({
                            type: 'signup',
                            email: email
                        });
                        alert('Письмо с подтверждением отправлено!');
                    }
                } else {
                    alert('Ошибка входа: ' + error.message);
                }
                return;
            }
    
            // Успешный вход
            if (data.user) {
                const username = data.user.user_metadata?.username || data.user.email.split('@')[0];
                localStorage.setItem('username', username);
                localStorage.setItem('supabase_session', JSON.stringify(data.session));
                
                alert('Вход выполнен успешно!');
                closeModal('modalLogin');
                window.location.href = '../account/account.html';
            }
    
        } catch (err) {
            console.error('Full Error:', err);
            alert('Ошибка входа: ' + err.message);
        }
    }
    
    

    // Инициализация всех компонентов
    slider.init();
    modal.init();

    // Глобальные функции
    window.openModal = modal.open;
    window.closeModal = modal.close;
    window.nextSlide = slider.nextSlide.bind(slider);
    window.prevSlide = slider.prevSlide.bind(slider);
    window.registerUser = registerUser;
});
