// Инициализация Supabase
const supabase = supabase.createClient(
    'https://rjhqvhwlwdhpbrtytxxp.supabase.co',
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJqaHF2aHdsd2RocGJydHl0eHhwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUyNjkwNjMsImV4cCI6MjA2MDg0NTA2M30.UuSxSWlp8VSyUyEsGFNkPQm3n2mqRw_hw7kDdz_DqSg'
);

// Функция смены аватара
function changeAvatar(newAvatarSrc) {
    console.log('Changing avatar to:', newAvatarSrc);
    
    try {
        // Обновляем изображение
        const avatarElement = document.getElementById('current-avatar');
        if (!avatarElement) {
            throw new Error('Элемент аватара не найден');
        }
        
        avatarElement.src = newAvatarSrc;
        localStorage.setItem('selectedAvatar', newAvatarSrc);
        
        // Сохраняем в Supabase
        supabase.auth.updateUser({
            data: { avatar: newAvatarSrc }
        }).then(({ error }) => {
            if (error) {
                console.error('Ошибка сохранения аватара:', error);
                alert('Не удалось сохранить аватар');
            } else {
                console.log('Аватар успешно обновлен');
            }
        });
    } catch (error) {
        console.error('Ошибка в changeAvatar:', error);
        alert('Произошла ошибка при смене аватара');
    }
}
 // Главная функция инициализации
async function initAccountPage() {
    console.log('Инициализация страницы аккаунта...');
    
    try {
        // 1. Настройка аватаров
        setupAvatarControls();
        
        // 2. Загрузка данных пользователя
        await loadUserData();
        
        console.log('Страница успешно инициализирована');
    } catch (error) {
        console.error('Ошибка инициализации:', error);
        alert('Произошла ошибка при загрузке страницы');
    }
}

// Настройка управления аватарами
function setupAvatarControls() {
    console.log('Настройка управления аватарами...');
    
    const avatarOptions = document.querySelectorAll('.avatar-option');
    console.log(`Найдено ${avatarOptions.length} вариантов аватара`);
    
    if (avatarOptions.length === 0) {
        console.error('Не найдены элементы для выбора аватара!');
        return;
    }
    
    // Обработчик для выбора аватара
    avatarOptions.forEach(option => {
        option.addEventListener('click', function() {
            const newAvatar = this.src;
            console.log('Выбран аватар:', newAvatar);
            changeAvatar(newAvatar);
        });
    });
    
    // Восстановление сохраненного аватара
    const savedAvatar = localStorage.getItem('selectedAvatar');
    if (savedAvatar) {
        const avatarImg = document.getElementById('current-avatar');
        if (avatarImg) {
            avatarImg.src = savedAvatar;
        }
    }
}
const testBtn = document.createElement('button');
testBtn.textContent = 'Тест аватара';
testBtn.onclick = () => changeAvatar('avatars/girl.png');
document.body.prepend(testBtn);

// Функция загрузки данных пользователя
async function loadUserData() {
    try {
        console.log('Загрузка данных пользователя...');
        
        // Проверяем текущую сессию
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError || !session) {
            console.warn('Пользователь не авторизован, перенаправление...');
            window.location.href = '../rule.html';
            return;
        }

        // Получаем данные пользователя
        const { data: { user } } = await supabase.auth.getUser();
        console.log('Данные пользователя:', user);
        
        if (!user) {
            throw new Error('Данные пользователя не получены');
        }

        // Устанавливаем имя
        const username = user.user_metadata?.username || user.email.split('@')[0];
        document.getElementById('user-name').textContent = username;
        localStorage.setItem('username', username);

        // Загружаем аватар
        const savedAvatar = localStorage.getItem('selectedAvatar') || 'avatars/user.png';
        document.getElementById('current-avatar').src = savedAvatar;

        // Работа с таблицей stats
        const { data: stats, error: statsError } = await supabase
            .from('stats')
            .select('*')
            .eq('user_id', user.id)
            .maybeSingle();

        if (statsError) throw statsError;

        if (!stats) {
            console.log('Создание новой записи статистики...');
            const { data: newStats, error: insertError } = await supabase
                .from('stats')
                .insert({
                    user_id: user.id,
                    total_points: 0,
                    total_levels: 0,
                    flash_points: 0,
                    flash_levels: 0,
                    lost_points: 0,
                    lost_levels: 0,
                    pairs_points: 0,
                    pairs_levels: 0
                })
                .select()
                .single();

            if (insertError) throw insertError;
            updateStats(newStats);
        } else {
            updateStats(stats);
        }
    } catch (error) {
        console.error('Ошибка загрузки данных:', error);
        alert('Произошла ошибка при загрузке данных аккаунта');
    }
}

// Функция обновления статистики на странице
function updateStats(stats) {
    console.log('Обновление статистики:', stats);
    
    const fields = {
        'total-points': 'total_points',
        'total-levels': 'total_levels',
        'flash-points': 'flash_points',
        'flash-levels': 'flash_levels',
        'lost-points': 'lost_points',
        'lost-levels': 'lost_levels',
        'pairs-points': 'pairs_points',
        'pairs-levels': 'pairs_levels'
    };

    for (const [elementId, fieldName] of Object.entries(fields)) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = stats[fieldName] || 0;
        }
    }
}
// Запуск при полной загрузке DOM
document.addEventListener('DOMContentLoaded', initAccountPage);

// Экспорт функций для глобального доступа
window.changeAvatar = changeAvatar;
window.initAccountPage = initAccountPage;